﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using JudsonSchoolApp;
using SQLite;
using Xamarin.Forms;
using XamSqlitestud.Droid;

[assembly: Dependency(typeof(GetSQLiteConnnection))]
namespace XamSqlitestud.Droid
{
    public class GetSQLiteConnnection : ISQLiteInterface
    {

        public SQLiteConnection GetConnection()
        {
            var sqliteFilename = "UserDatabase.db3";
            string documentsPath = System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal); // Documents folder
            var path = Path.Combine(documentsPath, sqliteFilename);

            var conn = new SQLiteConnection(path, SQLiteOpenFlags.ReadWrite | SQLiteOpenFlags.Create | SQLiteOpenFlags.SharedCache);

            // Return the database connection 
            return conn;
            //var fileName = "UserDatabase.db3";
            //var documentPath = System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal);
            //var path = Path.Combine(documentPath, fileName);
            ////var platform = new SQLite.Net.Platform.XamarinAndroid.SQLitePlatformAndroid();
            
            //var connection = new SQLiteConnection(path);
            //return connection;
        }
    }
}