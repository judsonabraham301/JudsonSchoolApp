﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JudsonSchoolApp
{
    public interface IStdLocHelper
    {
        string GetLocalFilePath(string filename);
    }
}
