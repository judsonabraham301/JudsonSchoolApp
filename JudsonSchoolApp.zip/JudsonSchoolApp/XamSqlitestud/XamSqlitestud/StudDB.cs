﻿using System;
using System.Collections.Generic;
using System.Text;

using System.Threading.Tasks;
using SQLite;

namespace JudsonSchoolApp
{
    public class StudDB
    {
        readonly SQLiteAsyncConnection database;
        public StudDB(string dbpath)
        {
            database = new SQLiteAsyncConnection(dbpath);
            database.CreateTableAsync<Student>().Wait();
        }
        public Task<List<Student>> GetStudentsAsync()
        {
            return database.Table<Student>().ToListAsync();
        }
        public Task<Student> GetStudentAsync(int id)
        {
            return database.Table<Student>().Where(i => i.stdid == id).FirstOrDefaultAsync();
        }

        public Task<int> SaveStudentAsync(Student student)
        {
            if (student.stdid != 0)
            {
                return database.UpdateAsync(student);
            }
            else
            {
                return database.InsertAsync(student);
            }
        }
        public Task<int> DeleteStudentAsync(Student student)
        {
            return database.DeleteAsync(student);
        }

        public Task<int> EditStudent(Student student)
        {
            return database.UpdateAsync(student);
        }
    }
}
