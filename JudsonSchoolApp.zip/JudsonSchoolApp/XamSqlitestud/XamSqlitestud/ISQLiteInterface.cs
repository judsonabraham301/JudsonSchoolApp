﻿using SQLite;
using System;
using System.Collections.Generic;
using System.Text;

namespace JudsonSchoolApp
{
    public interface ISQLiteInterface
    {
        SQLiteConnection GetConnection();
    }
}
