﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace JudsonSchoolApp
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class AddStudent : ContentPage
	{
		public AddStudent ()
		{
			InitializeComponent ();
		}

        async void Save_Clicked(object sender, System.EventArgs e)
        {
            var personItem = (Student)BindingContext;
            await App.Database.SaveStudentAsync(personItem);
            await Navigation.PopAsync();
        }
        async void Cancel_Clicked(object sender, System.EventArgs e)
        {
            
            await Navigation.PopAsync();
        }
    }
}