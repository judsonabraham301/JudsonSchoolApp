﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace JudsonSchoolApp
{
	public partial class StudentPage : ContentPage
	{
        public StudentPage()
        {
            InitializeComponent();
            this.Title = "Add Students";
            var toolbarItem = new ToolbarItem { Text = "+" };
            toolbarItem.Clicked += async (sender, e) =>
            {
                await Navigation.PushAsync(new AddStudent() { BindingContext = new Student() });
            };
            ToolbarItems.Add(toolbarItem);
        }
        protected async override void OnAppearing()
        {
            base.OnAppearing();
            StudListview.ItemsSource = await App.Database.GetStudentsAsync();
        }
        async void Student_Itemselected(object sender, SelectedItemChangedEventArgs e)
        {
            if (e.SelectedItem != null)
            {
                await Navigation.PushAsync(new EditStudent() { BindingContext = e.SelectedItem as Student });
            }
        }
    }
}

