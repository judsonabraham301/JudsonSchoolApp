﻿using System;
using System.Collections.Generic;
using System.Text;
using SQLite;

namespace JudsonSchoolApp
{
    public class Student
    {
        [PrimaryKey, AutoIncrement]
        public int stdid { get; set; }
        [NotNull]
        public string stdname { get; set; }
        public string stdcourse { get; set; }
        public int stdage { get; set; }
    }
}
